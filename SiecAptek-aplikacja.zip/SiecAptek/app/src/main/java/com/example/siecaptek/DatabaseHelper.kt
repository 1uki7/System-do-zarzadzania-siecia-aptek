package com.example.siecaptek

import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException

object DatabaseHelper {
    private const val HOST = "database-1.ct6skksyahra.eu-north-1.rds.amazonaws.com"
    private const val PORT = "3306"
    private const val DATABASE_NAME = "siec_aptek"
    private const val USER = "admin"
    private const val PASS = "Pa\$\$word123"

    private const val URL = "jdbc:mysql://$HOST:$PORT/$DATABASE_NAME?useSSL=false&allowPublicKeyRetrieval=true"

    fun getConnection(): Connection? {
        return try {
            Class.forName("com.mysql.jdbc.Driver")
            DriverManager.getConnection(URL, USER, PASS)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun setCurrentUser(connection: Connection, userId: Int) {
        try {
            val statement = connection.prepareStatement("SET @current_user_id = ?")
            statement.setInt(1, userId)
            statement.execute()
            statement.close()
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }
}