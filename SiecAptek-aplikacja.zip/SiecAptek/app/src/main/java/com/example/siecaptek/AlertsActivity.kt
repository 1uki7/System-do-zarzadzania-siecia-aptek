package com.example.siecaptek

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AlertsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alerts)

        val recyclerView = findViewById<RecyclerView>(R.id.alertRecyclerView)
        val refreshBtn = findViewById<Button>(R.id.refreshAlertsBtn) // DODANO POWIĄZANIE PRZYCISKU

        recyclerView.layoutManager = LinearLayoutManager(this)

        // Ładowanie danych przy starcie aktywności
        loadAlertsFromDb(recyclerView)

        // OBSŁUGA PRZYCISKU ODŚWIEŻ
        refreshBtn.setOnClickListener {
            loadAlertsFromDb(recyclerView)
            Toast.makeText(this, "Odświeżanie...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadAlertsFromDb(recyclerView: RecyclerView) {
        CoroutineScope(Dispatchers.IO).launch {
            val conn = DatabaseHelper.getConnection()
            val alertList = mutableListOf<Alert>()

            if (conn != null) {
                try {
                    val query = """
                        SELECT poziom, opis, data_zdarzenia 
                        FROM log_systemowy 
                        WHERE poziom IN ('ostrzeżenie', 'krytyczny') 
                        ORDER BY data_zdarzenia DESC 
                        LIMIT 20
                    """.trimIndent()

                    val stmt = conn.createStatement()
                    val rs = stmt.executeQuery(query)

                    while (rs.next()) {
                        alertList.add(
                            Alert(
                                poziom = rs.getString("poziom") ?: "info",
                                opis = rs.getString("opis") ?: "",
                                data = rs.getString("data_zdarzenia") ?: ""
                            )
                        )
                    }

                    withContext(Dispatchers.Main) {
                        recyclerView.adapter = AlertsAdapter(alertList)
                    }

                    rs.close()
                    stmt.close()
                } catch (e: Exception) {
                    e.printStackTrace()
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@AlertsActivity, "Błąd pobierania: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                } finally {
                    conn.close()
                }
            } else {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@AlertsActivity, "Brak połączenia z AWS", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}