package com.example.siecaptek

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val loginBtn = findViewById<Button>(R.id.loginButton)
        val loginEt = findViewById<EditText>(R.id.loginEditText)
        val passEt = findViewById<EditText>(R.id.passwordEditText)
        val statusTv = findViewById<TextView>(R.id.statusTextView)

        loginBtn.setOnClickListener {
            val loginInput = loginEt.text.toString()
            val passwordInput = passEt.text.toString()

            if (loginInput.isEmpty() || passwordInput.isEmpty()) {
                statusTv.text = "Wypełnij wszystkie pola"
                return@setOnClickListener
            }

            statusTv.text = "Logowanie..."

            CoroutineScope(Dispatchers.IO).launch {
                val conn = DatabaseHelper.getConnection()
                if (conn != null) {
                    try {
                        val query = "SELECT id_pracownika FROM pracownicy WHERE login = ? AND haslo = ?"
                        val stmt = conn.prepareStatement(query)
                        stmt.setString(1, loginInput)
                        stmt.setString(2, passwordInput)
                        val rs = stmt.executeQuery()

                        if (rs.next()) {
                            val userId = rs.getInt("id_pracownika")

                            withContext(Dispatchers.Main) {
                                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                                // PRZEKAZYWANIE DANYCH SESJI
                                intent.putExtra("USER_ID", userId)
                                intent.putExtra("USER_LOGIN", loginInput) // TA LINIA NAPRAWIA "NIEZNANEGO"

                                startActivity(intent)
                                finish()
                            }
                        } else {
                            withContext(Dispatchers.Main) {
                                statusTv.text = "Błędny login lub hasło"
                            }
                        }
                        rs.close()
                        stmt.close()
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            statusTv.text = "Błąd bazy: ${e.message}"
                        }
                    } finally {
                        conn.close()
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        statusTv.text = "Brak połączenia z AWS"
                    }
                }
            }
        }
    }
}