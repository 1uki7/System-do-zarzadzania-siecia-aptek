package com.example.siecaptek

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Klasa danych opisująca pojedynczy alert
data class Alert(
    val poziom: String,
    val opis: String,
    val data: String
)

class AlertsAdapter(private val alerts: List<Alert>) : RecyclerView.Adapter<AlertsAdapter.AlertViewHolder>() {

    class AlertViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Zmienione powiązania pod nowy layout item_alert.xml (Krok 20)
        val indicator: View = view.findViewById(R.id.alertPriorityIndicator)
        val levelTv: TextView = view.findViewById(R.id.alertLevel)
        val descTv: TextView = view.findViewById(R.id.alertDescription)
        val dateTv: TextView = view.findViewById(R.id.alertDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlertViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alert, parent, false)
        return AlertViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlertViewHolder, position: Int) {
        val alert = alerts[position]

        holder.levelTv.text = alert.poziom.uppercase()
        holder.descTv.text = alert.opis
        holder.dateTv.text = alert.data

        // --- NOWA LOGIKA KOLOROWANIA PASKA (Zgodna z Blue & White UI) ---
        when (alert.poziom.lowercase()) {
            "krytyczny" -> {
                holder.indicator.setBackgroundColor(Color.parseColor("#D32F2F")) // Ciemny czerwony
                holder.levelTv.setTextColor(Color.parseColor("#D32F2F"))
            }
            "ostrzeżenie" -> {
                holder.indicator.setBackgroundColor(Color.parseColor("#FBC02D")) // Żółty/Bursztynowy
                holder.levelTv.setTextColor(Color.parseColor("#FBC02D"))
            }
            else -> {
                holder.indicator.setBackgroundColor(Color.parseColor("#1976D2")) // Niebieski (Info)
                holder.levelTv.setTextColor(Color.parseColor("#1976D2"))
            }
        }
    }

    override fun getItemCount(): Int = alerts.size
}