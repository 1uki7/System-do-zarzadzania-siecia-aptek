package com.example.siecaptek

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.sql.Connection

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // KONFIGURACJA TOOLBARA
        val toolbar = findViewById<Toolbar>(R.id.main_toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "SYSTEM SIECI APTEK"

        val userId = intent.getIntExtra("USER_ID", -1)
        val userLogin = intent.getStringExtra("USER_LOGIN") ?: "Nieznany"

        val tvUserSession = findViewById<TextView>(R.id.tvUserSession)
        val pharmacyContainer = findViewById<LinearLayout>(R.id.pharmacyContainer)
        val testBtn = findViewById<Button>(R.id.testTriggerBtn)

        tvUserSession.text = "Zalogowany jako: $userLogin (ID: $userId)"

        fetchPharmaciesToCards(pharmacyContainer)

        testBtn.setOnClickListener {
            if (userId != -1) runTriggerTest(userId)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_alerts -> {
                startActivity(Intent(this, AlertsActivity::class.java))
                return true
            }
            R.id.action_logout -> {
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
                Toast.makeText(this, "Wylogowano pomyślnie", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun fetchPharmaciesToCards(container: LinearLayout) {
        CoroutineScope(Dispatchers.IO).launch {
            var conn: Connection? = null
            try {
                conn = DatabaseHelper.getConnection()
                if (conn != null) {
                    val rs = conn.createStatement().executeQuery("SELECT nazwa, adres, status FROM apteki")
                    while (rs.next()) {
                        val nazwa = rs.getString("nazwa")
                        val adres = rs.getString("adres")
                        val statusDB = rs.getString("status")

                        withContext(Dispatchers.Main) {
                            val card = LayoutInflater.from(this@MainActivity).inflate(R.layout.item_apteka, container, false)
                            card.findViewById<TextView>(R.id.tvAptekaNazwa).text = nazwa
                            card.findViewById<TextView>(R.id.tvAptekaAdres).text = adres
                            val statusTv = card.findViewById<TextView>(R.id.tvAptekaStatus)
                            statusTv.text = statusDB.uppercase()
                            statusTv.setBackgroundColor(if (statusDB.contains("nieczynna", true)) Color.parseColor("#D32F2F") else Color.parseColor("#1976D2"))
                            container.addView(card)
                        }
                    }
                }
            } catch (e: Exception) { e.printStackTrace() } finally { conn?.close() }
        }
    }

    private fun runTriggerTest(userId: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            var conn: Connection? = null
            try {
                conn = DatabaseHelper.getConnection()
                if (conn != null) {
                    DatabaseHelper.setCurrentUser(conn, userId)
                    conn.createStatement().executeUpdate("UPDATE magazyn_apteki SET ilosc_dostepna = 5 WHERE id_magazynu = 185")
                    withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "Test triggera wysłany!", Toast.LENGTH_SHORT).show() }
                }
            } catch (e: Exception) { e.printStackTrace() } finally { conn?.close() }
        }
    }
}